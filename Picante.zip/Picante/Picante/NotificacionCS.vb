﻿Public Class NotificacionCS
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
        AgregarComida.Close()


    End Sub
End Class